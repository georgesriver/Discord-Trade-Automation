# Discord-Trade-Automation

**美股雷达 + Discord 交易信号全链路自动化**

一个项目同时解决两件事：

1. **Market Pulse** — 美股实时雷达（市场概览、板块热力图、异动股、财报/经济日历、新闻）
2. **TradeForge** — Discord 信号 → 解析 → 风控 → Moomoo 自动执行

> 机器负责速度 · 规则负责风险 · 人保留最终控制权

---

## 系统架构

```
┌─────────────────────────────────────────────────────────────┐
│                     Market Pulse 仪表盘                      │
│  Overview │ Heatmap │ Movers │ Earnings │ Economic │ News   │
│                     + 实时信号流面板                          │
└─────────────────────────────────────────────────────────────┘
                              ↑
┌──────────────┐    ┌─────────────────┐    ┌──────────────┐
│   Discord    │ →  │ Chrome Extension│ →  │ 本地中继服务  │
│  交易信息群   │    │  消息捕获转发    │    │ relay_server │
└──────────────┘    └─────────────────┘    └──────┬───────┘
                                                   │
                     ┌─────────────────────────────┼─────────────────────────────┐
                     ↓                             ↓                             ↓
              ┌─────────────┐              ┌─────────────┐              ┌─────────────┐
              │   Parser    │              │ Risk Engine │              │  Moomoo API │
              │ 信号结构化   │      →       │  验证+风控   │      →       │   自动执行   │
              └─────────────┘              └─────────────┘              └─────────────┘
```

---

## 目录结构

```
Discord-Trade-Automation/
├── chrome-extension/          # Discord Web 消息捕获扩展
│   ├── manifest.json
│   ├── content.js
│   ├── background.js
│   └── popup.html
├── dashboard/                 # Market Pulse 前端
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js
├── backend/
│   ├── parser/signal_parser.py
│   ├── risk/risk_engine.py
│   └── execution/moomoo_executor.py
├── relay_server.py            # 本地中继（连接 Extension ↔ 解析/风控/执行）
├── requirements.txt
└── README.md
```

---

## 快速开始

### 1. 启动本地中继（解析 + 风控 + 执行）

```bash
cd Discord-Trade-Automation
python relay_server.py
# 默认监听 http://127.0.0.1:8765/signal
```

### 2. 加载 Chrome Extension

1. 打开 `chrome://extensions/`
2. 开启「开发者模式」
3. 「加载已解压的扩展程序」→ 选择 `chrome-extension/` 目录
4. 打开 Discord Web，进入交易信号频道

### 3. 打开 Market Pulse 仪表盘

```bash
cd dashboard
python -m http.server 8080
# 浏览器访问 http://localhost:8080
```

仪表盘会显示市场数据，并实时接收来自中继的交易信号。

---

## 功能清单

### Market Pulse
- [x] Market Overview（SPX / NDX / DJI）
- [x] Sector Heatmap
- [x] Biggest Movers
- [x] Earnings Calendar
- [x] Economic Calendar
- [x] Latest News
- [x] 实时信号流（来自 Discord）

### Discord 自动化链路
- [x] Chrome Extension 捕获可见消息
- [x] 转发到本地中继
- [x] 信号解析（BUY/SELL/加仓/止损/CALL/PUT）
- [x] 风控（去重、冷却、仓位、置信度、黑白名单）
- [x] Moomoo 执行接口（模拟盘可跑）

---

## 免责声明

本项目仅供个人学习与研究。自动交易存在风险，请充分理解后再使用。作者不对任何交易损失负责。

---

**Build your own trading infrastructure.**
