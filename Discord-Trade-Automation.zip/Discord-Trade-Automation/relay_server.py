"""
本地中继服务
接收 Chrome Extension 消息 → 解析 → 风控 → 执行
同时提供 /recent 接口给仪表盘拉取信号
"""
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
import json
import sys
import os
from collections import deque
from threading import Lock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "backend"))

from parser.signal_parser import parse_signal
from risk.risk_engine import RiskEngine, Decision
from execution.moomoo_executor import MoomooExecutor, OrderRequest, OrderSide

engine = RiskEngine(max_position_size=500, min_confidence=0.45)
executor = MoomooExecutor(paper=True)
executor.connect()

# 最近信号缓存（给仪表盘用）
recent_signals = deque(maxlen=50)
lock = Lock()


class Handler(BaseHTTPRequestHandler):
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        if self.path == "/recent":
            with lock:
                data = list(recent_signals)
                recent_signals.clear()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._cors()
            self.end_headers()
            self.wfile.write(json.dumps(data).encode())
            return
        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        if self.path != "/signal":
            self.send_response(404)
            self.end_headers()
            return

        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        try:
            data = json.loads(body)
        except Exception:
            self.send_response(400)
            self.end_headers()
            return

        text = data.get("text", "")
        print(f"\n[消息] {text[:100]}")

        signal = parse_signal(text)
        print(f"[解析] {signal.action.value} {signal.ticker} qty={signal.quantity} conf={signal.confidence:.2f}")

        result = engine.evaluate(signal)
        print(f"[风控] {result.decision.value} — {result.reason}")

        record = {
            **signal.to_dict(),
            "decision": result.decision.value,
            "reason": result.reason,
        }

        if result.decision == Decision.ALLOW and signal.ticker and signal.action.value in ("BUY", "SELL"):
            side = OrderSide.BUY if signal.action.value == "BUY" else OrderSide.SELL
            order = OrderRequest(ticker=signal.ticker, side=side, quantity=signal.quantity or 1)
            er = executor.place_order(order)
            record["order_id"] = er.order_id
            print(f"[执行] {er.message}")

        with lock:
            recent_signals.append(record)

        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self._cors()
        self.end_headers()
        self.wfile.write(json.dumps({"status": "ok"}).encode())

    def log_message(self, *args):
        pass


if __name__ == "__main__":
    port = 8765
    print(f"中继已启动 → http://127.0.0.1:{port}")
    print("  POST /signal  接收 Extension 消息")
    print("  GET  /recent  仪表盘拉取信号")
    HTTPServer(("127.0.0.1", port), Handler).serve_forever()
